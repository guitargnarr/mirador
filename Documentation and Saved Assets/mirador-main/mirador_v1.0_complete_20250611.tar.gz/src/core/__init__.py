"""
Mirador Core Package

Contains core functionality for the Mirador AI Framework.
"""

__version__ = "0.2.0"