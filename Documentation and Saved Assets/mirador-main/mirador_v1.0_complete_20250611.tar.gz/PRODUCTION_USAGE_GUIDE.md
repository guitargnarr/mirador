# Mirador Production Usage Guide

## ✅ SYSTEM STATUS: FULLY OPERATIONAL

### Optimal Model Combinations

#### For Financial Planning
```bash
mirador-ez chain "financial question" financial_planning_expert_v5 enhanced_agent_fast_v6
mirador-ez chain "Louisville question" louisville_expert_v2 enhanced_agent_fast_v6
mirador-ez chain "complex life decision" financial_planning_expert_v5 louisville_expert_v2 enhanced_agent_fast_v6
