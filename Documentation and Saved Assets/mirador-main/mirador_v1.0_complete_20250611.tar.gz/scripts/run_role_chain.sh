#!/usr/bin/env bash
# Run the Mirador role-based chain

# Simply pass through to the main implementation
~/ai_framework_git/src/chains/role_chain.sh "$@"